# Security Policy

## Supported Versions

Our maintained and support version to submit a security vulnerability.

| Version | Supported          |
| ------- | ------------------ |
| 1.5.x   | :white_check_mark: |
| 1.4     | :white_check_mark: |

## Reporting a Vulnerability

If you find a vulnerabilty or an exploit, you may report it on our
[Discord Server](https://discord.gg/CvqRH9TrYK) or in [Security Tab](https://github.com/CR072/HolaClient/security) present in our GitHub repo.
